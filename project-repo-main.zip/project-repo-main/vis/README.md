# Vehicle-Insurance-System
Vehicle Insurance System is a Web Application developed using Spring MVC and Hibernate. The goal of the application is to provide a dashboard to the Insurance company where they can keep track of their customers.
