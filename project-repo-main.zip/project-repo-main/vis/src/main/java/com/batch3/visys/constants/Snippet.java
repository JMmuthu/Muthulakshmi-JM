package com.batch3.visys.constants;

public class Snippet {
	public static void main(String[] args) {
		
	}
}

